roslaunch nao_bringup nao_full_py.launch

roslaunch nao_apps tactile.launch

rosrun tutorial_2 central_node.py